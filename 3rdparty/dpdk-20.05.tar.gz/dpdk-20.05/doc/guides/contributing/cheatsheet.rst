..  SPDX-License-Identifier: BSD-3-Clause
    Copyright 2018 The DPDK contributors

Patch Cheatsheet
================

.. _figure_patch_cheatsheet:

.. figure:: img/patch_cheatsheet.*

   Cheat sheet for submitting patches to dev@dpdk.org
