// ini_storage.h
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _HYPERON_TEST_INI_STORAGE_H_
#define _HYPERON_TEST_INI_STORAGE_H_

#include "test.h"

//////////////////////////////////////////////////
// class ini_storage_test
//
class ini_storage_test : public test
{
public:
	ini_storage_test();

	virtual void execute();
};

#endif // _HYPERON_TEST_INI_STORAGE_H_
