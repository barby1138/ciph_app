// properties.h
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _HYPERON_TEST_PROPERTIES_H_
#define _HYPERON_TEST_PROPERTIES_H_

#include "test.h"
#include <hyperon/properties.h>

//////////////////////////////////////////////////
// class properties
//
class properties_test : public test
{
public:
	properties_test();

	virtual void execute();
};

#endif // _HYPERON_TEST_PROPERTIES_H_
