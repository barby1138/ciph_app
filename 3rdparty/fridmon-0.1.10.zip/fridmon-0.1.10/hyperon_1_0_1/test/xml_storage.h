// xml_storage.h
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _HYPERON_TEST_XML_STORAGE_H_
#define _HYPERON_TEST_XML_STORAGE_H_

#include "test.h"

//////////////////////////////////////////////////
// class xml_storage_test
//
class xml_storage_test : public test
{
public:
	xml_storage_test();

	virtual void execute();
};

#endif // _HYPERON_TEST_XML_STORAGE_H_
