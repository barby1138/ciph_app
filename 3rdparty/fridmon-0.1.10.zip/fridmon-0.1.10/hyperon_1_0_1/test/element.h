// element.h
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _HYPERON_TEST_ELEMENT_H_
#define _HYPERON_TEST_ELEMENT_H_

#include "test.h"
#include <hyperon/element.h>

//////////////////////////////////////////////////
// class element_test
//
class element_test : public test
{
public:
	element_test();

	virtual void execute();
};

#endif // _HYPERON_TEST_ELEMENT_H_


